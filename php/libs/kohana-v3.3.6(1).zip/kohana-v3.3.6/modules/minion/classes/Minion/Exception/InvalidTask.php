<?php defined('SYSPATH') or die('No direct script access.');

class Minion_Exception_InvalidTask extends Kohana_Minion_Exception_InvalidTask {}
