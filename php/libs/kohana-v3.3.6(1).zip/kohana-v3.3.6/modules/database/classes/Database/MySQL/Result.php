<?php defined('SYSPATH') OR die('No direct script access.');

class Database_MySQL_Result extends Kohana_Database_MySQL_Result {}
