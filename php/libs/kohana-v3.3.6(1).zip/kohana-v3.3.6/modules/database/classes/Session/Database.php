<?php defined('SYSPATH') OR die('No direct script access.');

class Session_Database extends Kohana_Session_Database {}
