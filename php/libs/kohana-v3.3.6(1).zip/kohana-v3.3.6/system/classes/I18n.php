<?php defined('SYSPATH') OR die('No direct script access.');

class I18n extends Kohana_I18n {}
