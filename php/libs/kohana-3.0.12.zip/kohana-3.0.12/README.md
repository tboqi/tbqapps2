# Kohana PHP Framework, version 3.0 (dev)

This is a maintenance version of [Kohana](http://kohanaframework.org/) 3.0.

For the most current release, see the 3.1/master branch.
