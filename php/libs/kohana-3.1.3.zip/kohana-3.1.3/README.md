# Kohana PHP Framework, version 3.1 (release)

This is the current release version of [Kohana](http://kohanaframework.org/).
